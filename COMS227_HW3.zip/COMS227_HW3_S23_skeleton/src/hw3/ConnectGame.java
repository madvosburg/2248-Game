package hw3;

import java.util.ArrayList;
import java.util.Random;

import api.ScoreUpdateListener;
import api.ShowDialogListener;
import api.Tile;

/**
 * Class that models a game.
 * 
 * @author Madison Vosburg
 */
public class ConnectGame {
	private ShowDialogListener dialogListener;
	private ScoreUpdateListener scoreListener;

	/**
	 * Keeps track of grid of tiles
	 */
	private Grid tileGrid;

	/**
	 * Keeps track of the maximum tile level
	 */
	private int maxTLevel;

	/**
	 * Keeps track of the minimum tile level
	 */
	private int minTLevel;

	/**
	 * Keeps track of random number generator
	 */
	private Random randNum;

	/**
	 * Keeps track of the player's score/points
	 */
	private long currScore = 0;

	/**
	 * Keeps track of selected tiles
	 */
	private ArrayList<Tile> selectedTiles;

	/**
	 * Constructs a new ConnectGame object with given grid dimensions and minimum
	 * and maximum tile levels.
	 * 
	 * @param width  grid width
	 * @param height grid height
	 * @param min    minimum tile level
	 * @param max    maximum tile level
	 * @param rand   random number generator
	 */
	public ConnectGame(int width, int height, int min, int max, Random rand) {
		tileGrid = new Grid(width, height);
		minTLevel = min;
		maxTLevel = max;
		this.randNum = rand;
		selectedTiles = new ArrayList<Tile>();

	}

	/**
	 * Gets a random tile with level between minimum tile level inclusive and
	 * maximum tile level exclusive. For example, if minimum is 1 and maximum is 4,
	 * the random tile can be either 1, 2, or 3.
	 * <p>
	 * DO NOT RETURN TILES WITH MAXIMUM LEVEL
	 * 
	 * @return a tile with random level between minimum inclusive and maximum
	 *         exclusive
	 */
	public Tile getRandomTile() {
		// rand.nextInt(max - min) + min;
		Tile temp = new Tile(randNum.nextInt(maxTLevel - minTLevel) + minTLevel);
		return temp;
	}

	/**
	 * Regenerates the grid with all random tiles produced by getRandomTile().
	 */
	public void radomizeTiles() {
		//for each tile in game grid, set tile to random
		for (int x = 0; x < tileGrid.getWidth(); x++) {
			for (int y = 0; y < tileGrid.getHeight(); y++) {
				tileGrid.setTile(getRandomTile(), x, y);
			}
		}
	}

	/**
	 * Determines if two tiles are adjacent to each other. They may be next to each
	 * other horizontally, vertically, or diagonally.
	 * 
	 * @param t1 one of the two tiles
	 * @param t2 one of the two tiles
	 * @return true if they are next to each other horizontally, vertically, or
	 *         diagonally on the grid, false otherwise
	 */
	public boolean isAdjacent(Tile t1, Tile t2) {
		// x and y have to be within 1 spot of each other to be adjacent.
		// Let's say we are comparing if one tile is above the other. The first tile
		// would be at position x,y. The second tile would be at position x,y+1. These
		// are adjacent because they are within 1 position away.
		if (Math.abs(t1.getX() - t2.getX()) <= 1) {
			if (Math.abs(t1.getY() - t2.getY()) <= 1) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Indicates the user is trying to select (clicked on) a tile to start a new
	 * selection of tiles.
	 * <p>
	 * If a selection of tiles is already in progress, the method should do nothing
	 * and return false.
	 * <p>
	 * If a selection is not already in progress (this is the first tile selected),
	 * then start a new selection of tiles and return true.
	 * 
	 * @param x the column of the tile selected
	 * @param y the row of the tile selected
	 * @return true if this is the first tile selected, otherwise false
	 */
	public boolean tryFirstSelect(int x, int y) {
		if (selectedTiles.size() > 0) {
			return false;
		}
		// add selected tile to array
		selectedTiles.add(tileGrid.getTile(x, y));
		// set selected tile to true
		tileGrid.getTile(x, y).setSelect(true);
		return true;
	}

	/**
	 * Indicates the user is trying to select (mouse over) a tile to add to the
	 * selected sequence of tiles. The rules of a sequence of tiles are:
	 * 
	 * <pre>
	 * 1. The first two tiles must have the same level.
	 * 2. After the first two, each tile must have the same level or one greater than the level of the previous tile.
	 * </pre>
	 * 
	 * For example, given the sequence: 1, 1, 2, 2, 2, 3. The next selected tile
	 * could be a 3 or a 4. If the use tries to select an invalid tile, the method
	 * should do nothing. If the user selects a valid tile, the tile should be added
	 * to the list of selected tiles.
	 * 
	 * @param x the column of the tile selected
	 * @param y the row of the tile selected
	 */
	public void tryContinueSelect(int x, int y) {
		Tile tile = tileGrid.getTile(x, y);

		// first two have to be the same
		// tiles have to be adjacent
		if (selectedTiles.size() > 0 && !isAdjacent(tile, selectedTiles.get(selectedTiles.size() - 1))) {
			return;
		}

		// unselect tile if the new tile is the same as previous selected
		if (selectedTiles.size() > 1 && tile.isSelected() && tile == selectedTiles.get(selectedTiles.size() - 2)) {
			unselect(selectedTiles.get(selectedTiles.size() - 1).getX(),
					selectedTiles.get(selectedTiles.size() - 1).getY());
			return;
		} else if (tile.isSelected()) {
			return;
		}
		// if selected one tile, the level must be the same
		if (selectedTiles.size() == 1) {
			if (selectedTiles.get(0).getLevel() == tile.getLevel()) {
				selectedTiles.add(tileGrid.getTile(x, y));
				tileGrid.getTile(x, y).setSelect(true);
			}
		} else if (selectedTiles.size() >= 2) {
			// if selected more than 2 tiles, level must be one above
			if ((tile.getLevel() == (selectedTiles.get(selectedTiles.size() - 1).getLevel()) + 1)
					|| (tile.getLevel() == selectedTiles.get(selectedTiles.size() - 1).getLevel())) {
				selectedTiles.add(tileGrid.getTile(x, y));
				tileGrid.getTile(x, y).setSelect(true);
			}
		}
	}

	/**
	 * Indicates the user is trying to finish selecting (click on) a sequence of
	 * tiles. If the method is not called for the last selected tile, it should do
	 * nothing and return false. Otherwise it should do the following:
	 * 
	 * <pre>
	 * 1. When the selection contains only 1 tile reset the selection and make sure all tiles selected is set to false.
	 * 2. When the selection contains more than one block:
	 *     a. Upgrade the last selected tiles with upgradeLastSelectedTile().
	 *     b. Drop all other selected tiles with dropSelected().
	 *     c. Reset the selection and make sure all tiles selected is set to false.
	 * </pre>
	 * 
	 * @param x the column of the tile selected
	 * @param y the row of the tile selected
	 * @return return false if the tile was not selected, otherwise return true
	 */
	public boolean tryFinishSelection(int x, int y) {
		// if the tile is not the last tile selected, return false
		if (selectedTiles.get(selectedTiles.size() - 1).getX() != x
				|| selectedTiles.get(selectedTiles.size() - 1).getY() != y) {
			return false;
		}
		// if selection only contains 1 tile, reset selected and set to false
		if (selectedTiles.size() == 1) {
			selectedTiles.get(0).setSelect(false);
			selectedTiles.clear();
			return true;
		}

		// when selection is more than 1, update score, upgrade selected, drop selected,
		// reset selected and set to false
		int updateScore = 0;
		for (Tile tile : selectedTiles) {
			updateScore += tile.getValue();
		}
		currScore += updateScore;
		scoreListener.updateScore(currScore);
		upgradeLastSelectedTile();
		dropSelected();
		for (Tile tile : selectedTiles) {
			tile.setSelect(false);
		}
		selectedTiles.clear();
		return true;
	}

	/**
	 * Increases the level of the last selected tile by 1 and removes that tile from
	 * the list of selected tiles. The tile itself should be set to unselected.
	 * <p>
	 * If the upgrade results in a tile that is greater than the current maximum
	 * tile level, both the minimum and maximum tile level are increased by 1. A
	 * message dialog should also be displayed with the message "New block 32,
	 * removing blocks 2". Not that the message shows tile values and not levels.
	 * Display a message is performed with dialogListener.showDialog("Hello,
	 * World!");
	 */
	public void upgradeLastSelectedTile() {
		Tile lastSelTile = selectedTiles.get(selectedTiles.size() - 1);
		// increase last selected tile level
		lastSelTile.setLevel(lastSelTile.getLevel() + 1);
		// remove tile from selected list
		lastSelTile.setSelect(false);
		selectedTiles.remove(selectedTiles.size() - 1);

		//if upgraded tile level is greater than max, increase max and min by 1, display message dialog
		if (lastSelTile.getLevel() > maxTLevel) {
			maxTLevel += 1;
			minTLevel += 1;
			dialogListener.showDialog("New block " + (int) Math.pow(2, maxTLevel) + ", removing blocks "
					+ (int) Math.pow(2, minTLevel - 1));
			dropLevel(minTLevel - 1);
		}
	}

	/**
	 * Gets the selected tiles in the form of an array. This does not mean selected
	 * tiles must be stored in this class as an array.
	 * 
	 * @return the selected tiles in the form of an array
	 */
	public Tile[] getSelectedAsArray() {
		Tile[] selectedTilesArr = new Tile[selectedTiles.size()];
		//convert selected tiles to array
		selectedTiles.toArray(selectedTilesArr);
		return selectedTilesArr;
	}

	/**
	 * Removes all tiles of a particular level from the grid. When a tile is
	 * removed, the tiles above it drop down one spot and a new random tile is
	 * placed at the top of the grid.
	 * 
	 * @param level the level of tile to remove
	 */
	public void dropLevel(int level) {
		for (int x = 0; x < tileGrid.getWidth(); x++) {
			for (int y = 0; y < tileGrid.getHeight(); y++) {
				Tile tile = tileGrid.getTile(x, y);

				if (tile.getLevel() == level) {
					// drop existing tile down one
					for (int lev = y; lev > 0; lev--) {
						tileGrid.setTile(tileGrid.getTile(x, lev - 1), x, lev);
					}
					// replace with a random tile at top row
					tileGrid.setTile(getRandomTile(), x, 0);
				}
			}
		}
	}

	/**
	 * Removes all selected tiles from the grid. When a tile is removed, the tiles
	 * above it drop down one spot and a new random tile is placed at the top of the
	 * grid.
	 */
	public void dropSelected() {
		for (Tile tile : selectedTiles) {
			for (int y = tile.getY(); y > 0; y--) {
				// drop existing tile down one
				tileGrid.setTile(tileGrid.getTile(tile.getX(), y - 1), tile.getX(), y);
			}
			// replace with a random tile at top row
			tileGrid.setTile(getRandomTile(), tile.getX(), 0);
		}
	}

	/**
	 * Remove the tile from the selected tiles.
	 * 
	 * @param x column of the tile
	 * @param y row of the tile
	 */
	public void unselect(int x, int y) {
		Tile tile = tileGrid.getTile(x, y);

		//make selected tile false
		tile.setSelect(false);
		selectedTiles.remove(selectedTiles.size() - 1);

	}

	/**
	 * Gets the player's score.
	 * 
	 * @return the score
	 */
	public long getScore() {
		return currScore;
	}

	/**
	 * Gets the game grid.
	 * 
	 * @return the grid
	 */
	public Grid getGrid() {
		return tileGrid;
	}

	/**
	 * Gets the minimum tile level.
	 * 
	 * @return the minimum tile level
	 */
	public int getMinTileLevel() {
		return minTLevel;
	}

	/**
	 * Gets the maximum tile level.
	 * 
	 * @return the maximum tile level
	 */
	public int getMaxTileLevel() {
		return maxTLevel;
	}

	/**
	 * Sets the player's score.
	 * 
	 * @param score number of points
	 */
	public void setScore(long score) {
		currScore = score;
	}

	/**
	 * Sets the game's grid.
	 * 
	 * @param grid game's grid
	 */
	public void setGrid(Grid grid) {
		tileGrid = grid;
	}

	/**
	 * Sets the minimum tile level.
	 * 
	 * @param minTileLevel the lowest level tile
	 */
	public void setMinTileLevel(int minTileLevel) {
		minTLevel = minTileLevel;
	}

	/**
	 * Sets the maximum tile level.
	 * 
	 * @param maxTileLevel the highest level tile
	 */
	public void setMaxTileLevel(int maxTileLevel) {
		maxTLevel = maxTileLevel;
	}

	/**
	 * Sets callback listeners for game events.
	 * 
	 * @param dialogListener listener for creating a user dialog
	 * @param scoreListener  listener for updating the player's score
	 */
	public void setListeners(ShowDialogListener dialogListener, ScoreUpdateListener scoreListener) {
		this.dialogListener = dialogListener;
		this.scoreListener = scoreListener;
	}

	/**
	 * Save the game to the given file path.
	 * 
	 * @param filePath location of file to save
	 */
	public void save(String filePath) {
		GameFileUtil.save(filePath, this);
	}

	/**
	 * Load the game from the given file path
	 * 
	 * @param filePath location of file to load
	 */
	public void load(String filePath) {
		GameFileUtil.load(filePath, this);
	}
}
