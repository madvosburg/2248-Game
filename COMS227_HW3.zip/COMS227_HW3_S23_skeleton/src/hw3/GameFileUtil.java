package hw3;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import api.Tile;

/**
 * Utility class with static methods for saving and loading game files.
 * 
 * @author Madison Vosburg
 */
public class GameFileUtil {
	/**
	 * Saves the current game state to a file at the given file path.
	 * <p>
	 * The format of the file is one line of game data followed by multiple lines of
	 * game grid. The first line contains the: width, height, minimum tile level,
	 * maximum tile level, and score. The grid is represented by tile levels. The
	 * conversion to tile values is 2^level, for example, 1 is 2, 2 is 4, 3 is 8, 4
	 * is 16, etc. The following is an example:
	 * 
	 * <pre>
	 * 5 8 1 4 100
	 * 1 1 2 3 1
	 * 2 3 3 1 3
	 * 3 3 1 2 2
	 * 3 1 1 3 1
	 * 2 1 3 1 2
	 * 2 1 1 3 1
	 * 4 1 3 1 1
	 * 1 3 3 3 3
	 * </pre>
	 * 
	 * @param filePath the path of the file to save
	 * @param game     the game to save
	 */
	public static void save(String filePath, ConnectGame game) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
			// write to file, can use writer.write()
			// https://docs.oracle.com/javase/8/docs/api/java/io/BufferedWriter.html#write-java.lang.String-int-int-
			// write(int c) --> writes a single character

			Grid grid = game.getGrid();

			// String that keeps track of game data/stats
			String data = grid.getWidth() + " " + grid.getHeight() + " " + game.getMinTileLevel() + " "
					+ game.getMaxTileLevel() + " " + game.getScore() + "\n";
			writer.write(data);
			
			//make each row of tiles
			for(int y = 0; y < grid.getHeight();y++) {
				for(int x = 0; x < grid.getWidth(); x++) {
					Tile tile = grid.getTile(x, y);
					writer.write("" + tile.getLevel());
					
					//there's no space at the end of the line
					if (x < grid.getWidth() - 1) {
						writer.write(" ");
					}
				}
				//there's no new line after the last row
				if (y < grid.getHeight() - 1) {
					writer.write("\n");
				}
			}
			
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Loads the file at the given file path into the given game object. When the
	 * method returns the game object has been modified to represent the loaded
	 * game.
	 * <p>
	 * See the save() method for the specification of the file format.
	 * 
	 * @param filePath the path of the file to load
	 * @param game     the game to modify
	 * @throws FileNotFoundException 
	 */
	public static void load(String filePath, ConnectGame game) {	
		File file = new File(filePath);
		Scanner scnr = null;
		try {
			scnr = new Scanner(file);
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//scan game data/stats
		int gridWidth = scnr.nextInt();
		int gridHeight = scnr.nextInt();
		int minTLevel = scnr.nextInt();
		int maxTLevel = scnr.nextInt();
		long score = scnr.nextLong();
		
		scnr.nextLine();
		
		//set in-game data/stats
		game.setGrid(new Grid(gridWidth, gridHeight));
		game.setMinTileLevel(minTLevel);
		game.setMaxTileLevel(maxTLevel);
		game.setScore(score);
		for(int y = 0; y < gridHeight; y++) {
			String line = scnr.nextLine();
			Scanner scnr2 = new Scanner(line);
			for (int x = 0; x < gridWidth; x++) {
				game.getGrid().setTile(new Tile(scnr2.nextInt()), x, y);
			}
			scnr2.close();
		}
		scnr.close();	
	}
}
